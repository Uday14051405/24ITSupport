<?php

namespace Spatie\Html\Elements;

use Spatie\Html\BaseElement;

class I extends BaseElement
{
    protected $tag = 'i';
}
