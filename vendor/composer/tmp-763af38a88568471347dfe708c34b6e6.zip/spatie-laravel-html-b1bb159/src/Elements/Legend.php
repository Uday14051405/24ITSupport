<?php

namespace Spatie\Html\Elements;

use Spatie\Html\BaseElement;

class Legend extends BaseElement
{
    protected $tag = 'legend';
}
