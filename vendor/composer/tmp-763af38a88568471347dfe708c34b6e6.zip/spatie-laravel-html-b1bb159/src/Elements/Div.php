<?php

namespace Spatie\Html\Elements;

use Spatie\Html\BaseElement;

class Div extends BaseElement
{
    protected $tag = 'div';
}
