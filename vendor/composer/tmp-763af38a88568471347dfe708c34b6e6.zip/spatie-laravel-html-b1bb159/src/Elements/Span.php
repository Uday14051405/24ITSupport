<?php

namespace Spatie\Html\Elements;

use Spatie\Html\BaseElement;

class Span extends BaseElement
{
    protected $tag = 'span';
}
