<?php

namespace Spatie\Html\Elements;

use Spatie\Html\BaseElement;

class P extends BaseElement
{
    protected $tag = 'p';
}
